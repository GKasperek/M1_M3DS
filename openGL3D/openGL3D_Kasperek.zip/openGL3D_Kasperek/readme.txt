﻿Gautier Kasperek

Question 8 : 
Il n'y a pas de délimitation des triangles car ils sont empilés et se recouvrent mutuellement pour dessiner la forme finale.

Question 9 :
1) La fonction GL_GREATER est un > alors que GL_LESS est un < pour la fonction de "depth".
Il n'y a aucune valeur strictement supérieur à 1
2) Les coordonnées du triangle rouge sont à -1 en depth
3) Certains sommets sont invisibles car leur depth est inférieur à 0.5

Problème rencontrés :
Je n'ai pas réussit à fixer l'éclairement, la source de lumière tourne en même temps que la vache.


